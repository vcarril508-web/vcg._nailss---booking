# VCG Nails — agenda de reservas

Proyecto inicial para publicar una página de reservas de VCG Nails con **GitHub + Vercel + Google Sheets + Google Drive + Gmail**.

## Qué incluye

- Diseño adaptable a celular, en tonos burdeos y crema.
- Servicios y precios transcritos de la gráfica enviada.
- Duraciones estimadas de 2 h para servicios básicos y 2 h 30 min para diseños.
- Selección de fecha y horarios de lunes a viernes, dentro de 13:00–18:00.
- Consulta de disponibilidad y bloqueo de horarios que ya tengan una solicitud activa.
- Formulario con nombre, WhatsApp, correo opcional, comentarios y foto de referencia (máx. 4 MB).
- Almacenamiento de solicitudes en Google Sheets y fotos privadas en Google Drive.
- Notificación por correo al recibir una solicitud.
- Estado inicial “Pendiente de abono”. La dueña confirma la reserva manualmente después de revisar el abono.

> Importante: la web registra solicitudes y evita choques de horario. No cobra automáticamente ni valida transferencias. Para una primera versión es más seguro enviar los datos de transferencia después de revisar la solicitud. La integración con Webpay/Mercado Pago puede añadirse más adelante.

## Paso 1 — Preparar Google Drive

1. En Google Drive crea una carpeta llamada `VCG Nails - Reservas`.
2. Dentro crea una hoja de cálculo llamada `Agenda VCG Nails`.
3. Copia el ID de la hoja desde su URL: `https://docs.google.com/spreadsheets/d/ESTE_ES_EL_ID/edit`.
4. Copia el ID de la carpeta desde su URL de Drive.
5. En la hoja se creará automáticamente una pestaña `Reservas` con las columnas necesarias al ejecutar la función de configuración.

## Paso 2 — Crear el backend en Google Apps Script

1. Abre https://script.google.com/ e inicia un proyecto nuevo.
2. Copia el contenido de `google-apps-script/Code.gs` y pégalo en el editor.
3. En **Configuración del proyecto → Propiedades del script**, agrega estas propiedades:

| Propiedad | Valor |
|---|---|
| `SPREADSHEET_ID` | ID de `Agenda VCG Nails` |
| `DRIVE_FOLDER_ID` | ID de la carpeta `VCG Nails - Reservas` |
| `NOTIFICATION_EMAIL` | `vcarril508@gmail.com` |
| `API_SECRET` | Una clave larga y aleatoria que inventes y guardes en privado |
| `DEPOSIT_AMOUNT` | `5000` (pesos chilenos) |
| `PAYMENT_INSTRUCTIONS` | Completa aquí tus datos bancarios para transferencia. No publiques la web hasta configurarlos. |

4. En la lista de funciones selecciona `setupVCGNails` y pulsa **Ejecutar**. Autoriza el acceso a Sheets.
5. Selecciona **Implementar → Nueva implementación → Aplicación web**.
6. Ejecutar como: **tu cuenta**. Quién tiene acceso: **Cualquier persona**. La API está protegida por `API_SECRET`; no publiques esa clave.
7. Implementa y copia la URL terminada en `/exec`.

Si cambias el código de Apps Script más adelante, crea una nueva versión desde **Implementar → Administrar implementaciones → Editar → Nueva versión**.

## Paso 3 — Subir a GitHub

1. Crea un repositorio nuevo en GitHub, por ejemplo `vcg-nails-booking`.
2. Sube todos los archivos de esta carpeta. No subas `.env.local` ni compartas tu `API_SECRET`.
3. Asegúrate de que estén incluidos `app/`, `public/`, `google-apps-script/`, `package.json` y `next.config.js`.

## Paso 4 — Publicar en Vercel

1. Entra a https://vercel.com/ e inicia sesión con GitHub.
2. Selecciona **Add New → Project** y conecta el repositorio.
3. Vercel detectará Next.js. Mantén los valores predeterminados.
4. En **Environment Variables** agrega:

| Variable | Valor |
|---|---|
| `GOOGLE_SCRIPT_URL` | URL `/exec` de Apps Script |
| `BOOKING_API_SECRET` | El mismo valor de `API_SECRET` |

5. Pulsa **Deploy**. Vercel entregará una dirección pública. Puedes conectar un dominio propio después.

## Cómo administrar las reservas

- Abre la hoja `Agenda VCG Nails`, pestaña `Reservas`.
- Cada fila nueva llega con estado `Pendiente de abono`.
- Cuando confirmes el abono, cambia el estado a `Confirmada`.
- Si la clienta cancela o no concreta, cambia el estado a `Cancelada` o `Rechazada`; así el horario vuelve a quedar disponible.
- Los estados `Pendiente de abono` y `Confirmada` bloquean el horario.
- Las fotos quedan en la carpeta de Drive y se mantienen privadas. El enlace queda registrado en la hoja.
- El correo de aviso incluye el código, nombre, WhatsApp, servicio, fecha, hora, total y enlace a la foto.
- Correo de notificaciones preconfigurado: `vcarril508@gmail.com`.
- Abono preconfigurado: `$5.000`.
- WhatsApp de contacto en Chile: `+56 9 7968 7302` (enlace directo desde el pie de página).
- La confirmación es manual: revisa la solicitud y el comprobante de transferencia antes de cambiar el estado a `Confirmada`.

## Reglas de agenda incluidas

- Lunes a viernes, de 13:00 a 18:00.
- Los inicios se ofrecen en intervalos de 30 minutos.
- Una cita de 2 horas puede comenzar hasta las 16:00.
- Una cita de 2 horas y media puede comenzar hasta las 15:30.
- Los horarios que se cruzan con una reserva pendiente o confirmada no se ofrecen.
- Se puede reservar hasta 3 meses hacia adelante.

## Antes de publicarla definitivamente

Completa los datos reales que faltan: datos de transferencia bancaria (titular, banco, tipo y número de cuenta, RUT y correo para comprobantes) y, si quieres, fotos adicionales de tu portafolio. El correo y el abono ya vienen preconfigurados. Los precios y servicios se pueden editar en `app/page.tsx` (arreglo `services`). Las duraciones se pueden ajustar en ese mismo arreglo.

## Desarrollo local

Requiere Node.js 18 o superior.

```bash
npm install
cp .env.example .env.local
# Completa GOOGLE_SCRIPT_URL y BOOKING_API_SECRET
npm run dev
```

Abre http://localhost:3000.
