'use client';

import { useEffect, useMemo, useState } from 'react';

type Service = { id: string; group: string; name: string; price: number; duration: number; description: string; tag?: string };
const services: Service[] = [
  { id: 'esmaltado-basico', group: 'Esmaltado permanente', name: 'Esmaltado básico', price: 10000, duration: 120, description: 'Preparación de la uña natural y esmaltado permanente en un tono.' },
  { id: 'esmaltado-francesa', group: 'Esmaltado permanente', name: 'Esmaltado francesa', price: 13000, duration: 120, description: 'Esmaltado permanente con terminación francesa.' },
  { id: 'esmaltado-full', group: 'Esmaltado permanente', name: 'Esmaltado full diseño', price: 15000, duration: 150, description: 'Esmaltado permanente con diseño. El tiempo puede variar según la complejidad.' },
  { id: 'kapping-basico', group: 'Kapping Builder Gel / Polygel', name: 'Kapping básico', price: 15000, duration: 120, description: 'Refuerzo de la uña natural con Builder Gel o Polygel.' },
  { id: 'kapping-diseno', group: 'Kapping Builder Gel / Polygel', name: 'Kapping diseño', price: 20000, duration: 150, description: 'Refuerzo de la uña natural con diseño personalizado.' },
  { id: 'softgel-basico', group: 'Soft Gel', name: 'Soft Gel básico', price: 20000, duration: 120, description: 'Extensiones con tips Soft Gel y esmaltado en un tono.' },
  { id: 'softgel-francesa', group: 'Soft Gel', name: 'Soft Gel francesa', price: 22000, duration: 150, description: 'Extensiones Soft Gel con terminación francesa.' },
  { id: 'softgel-full', group: 'Soft Gel', name: 'Soft Gel full diseño', price: 25000, duration: 150, description: 'Extensiones Soft Gel con diseño personalizado.' },
];
const money = (n: number) => '$' + n.toLocaleString('es-CL');
const groups = ['Esmaltado permanente', 'Kapping Builder Gel / Polygel', 'Soft Gel'];

export default function Home() {
  const [selected, setSelected] = useState(services[0].id);
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [slots, setSlots] = useState<string[]>([]);
  const [loadingSlots, setLoadingSlots] = useState(false);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [design, setDesign] = useState('Simple');
  const [notes, setNotes] = useState('');
  const [image, setImage] = useState('');
  const [imageName, setImageName] = useState('');
  const [removal, setRemoval] = useState(false);
  const [status, setStatus] = useState('');
  const [depositAmount, setDepositAmount] = useState(0);
  const [paymentInstructions, setPaymentInstructions] = useState('');
  const [sending, setSending] = useState(false);
  const service = services.find(s => s.id === selected)!;
  const total = service.price + (removal ? 3000 : 0);
  const minDate = new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 10);
  const maxDate = useMemo(() => { const d = new Date(); d.setMonth(d.getMonth() + 3); return d.toISOString().slice(0, 10); }, []);

  useEffect(() => {
    fetch('/api/settings').then(r => r.json()).then(data => { setDepositAmount(Number(data.depositAmount || 0)); setPaymentInstructions(String(data.paymentInstructions || '')); }).catch(() => {});
  }, []);

  useEffect(() => {
    if (!date) { setSlots([]); setTime(''); return; }
    setLoadingSlots(true); setTime('');
    fetch(`/api/availability?date=${date}&duration=${service.duration}`)
      .then(r => r.json()).then(data => setSlots(data.slots || []))
      .catch(() => setSlots([])).finally(() => setLoadingSlots(false));
  }, [date, service.duration]);

  function chooseImage(file?: File) {
    if (!file) return;
    if (file.size > 4 * 1024 * 1024) { setStatus('La foto debe pesar menos de 4 MB.'); return; }
    if (!file.type.startsWith('image/')) { setStatus('Selecciona un archivo de imagen.'); return; }
    const reader = new FileReader();
    reader.onload = () => { setImage(String(reader.result)); setImageName(file.name); setStatus(''); };
    reader.readAsDataURL(file);
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault(); setStatus('');
    if (!time) { setStatus('Selecciona un horario disponible.'); return; }
    setSending(true);
    try {
      const res = await fetch('/api/bookings', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name, phone, email, service: service.name, serviceId: service.id, design, date, time, duration: String(service.duration), notes, removal, total, referenceImage: image }) });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data.error || 'No se pudo registrar la solicitud.');
      setStatus(`¡Solicitud enviada! Tu código es ${data.bookingId}. Te contactaremos para confirmar la hora y los datos del abono.`);
      setName(''); setPhone(''); setEmail(''); setNotes(''); setImage(''); setImageName(''); setTime(''); setDate(''); setRemoval(false);
    } catch (err) { setStatus(err instanceof Error ? err.message : 'Ocurrió un error.'); }
    finally { setSending(false); }
  }

  return <main>
    <header className="topbar"><a className="brand" href="#inicio"><span className="monogram">VCG</span><span>NAILS<small>SOFT GEL · KAPPING · ESMALTADO</small></span></a><a className="top-link" href="#reservar">Reservar hora <span>↗</span></a></header>
    <section className="hero" id="inicio"><div className="hero-pattern"/><div className="hero-copy"><p className="eyebrow">BEAUTY STUDIO · EL BOSQUE</p><h1>Tus uñas,<br/><i>tu estilo.</i></h1><p className="hero-text">Un espacio para realzar tu estilo con detalles hechos con dedicación.</p><a className="primary" href="#reservar">AGENDA TU HORA <span>→</span></a><p className="hero-note">Atención personalizada · Lunes a viernes</p></div><div className="hero-stamp"><span>VCG</span><small>NAILS STUDIO</small><b>✳</b></div></section>

    <section className="section services" id="servicios"><div className="section-heading"><p className="eyebrow">ELIGE TU SERVICIO</p><h2>Servicios & <i>precios</i></h2><p>Selecciona el servicio que te gustaría realizarte. Los diseños más elaborados pueden requerir tiempo adicional.</p></div>
      {groups.map(group => <div className="service-group" key={group}><h3>{group}</h3><div className="service-grid">{services.filter(s => s.group === group).map(s => <button type="button" className={`service-card ${selected === s.id ? 'chosen' : ''}`} key={s.id} onClick={() => { setSelected(s.id); document.getElementById('reservar')?.scrollIntoView({ behavior: 'smooth' }); }}><span className="service-name">{s.name}</span><span className="service-desc">{s.description}</span><span className="service-bottom"><b>{money(s.price)}</b><small>{s.duration === 120 ? 'Aprox. 2 horas' : 'Aprox. 2 h 30 min'}</small></span><span className="select-mark">{selected === s.id ? '✓ Seleccionado' : '+ Elegir'}</span></button>)}</div></div>)}
      <div className="extra"><span>＋</span><div><b>Retiro de trabajos anteriores</b><small>Retiro de servicios realizados previamente · {money(3000)}</small></div><label className="switch"><input type="checkbox" checked={removal} onChange={e => setRemoval(e.target.checked)}/><span/></label></div>
    </section>

    <section className="gallery section"><div className="section-heading"><p className="eyebrow">INSPÍRATE</p><h2>Tu próxima <i>manicure</i></h2><p>¿Tienes una idea en mente? Adjunta una foto de referencia al momento de reservar.</p></div><div className="portfolio-grid"><figure><img src="/portfolio-softgel-1.jpg" alt="Trabajo de uñas realizado por VCG Nails"/><figcaption>Diseños realizados · VCG Nails</figcaption></figure><figure><img src="/portfolio-softgel-2.jpg" alt="Manicure con diseño realizado por VCG Nails"/><figcaption>Inspiración para tu próxima cita</figcaption></figure></div><div className="gallery-note"><div className="gallery-flower">✳</div><div><b>Diseños a tu medida</b><p>La fotografía nos ayuda a conocer el estilo que buscas. El precio y la duración final pueden variar según los detalles, largo y complejidad del diseño. Lo confirmaremos contigo antes de comenzar.</p></div></div></section>

    <section className="booking section" id="reservar"><div className="booking-intro"><p className="eyebrow">BOOK YOUR APPOINTMENT</p><h2>Reserva tu <i>momento.</i></h2><p>Completa tus datos y elige el horario que mejor te acomode. Tu solicitud quedará pendiente hasta que confirmemos el abono.</p><div className="hours"><span>HORARIO DE ATENCIÓN</span><b>Lunes a viernes</b><strong>13:00 — 18:00</strong><small>Duración estimada según servicio: 2 a 2,5 horas.</small></div></div>
      <form className="booking-form" onSubmit={submit}><div className="form-title"><span>01 / 03</span><h3>Tu servicio</h3></div><label>Servicio seleccionado<select value={selected} onChange={e => setSelected(e.target.value)}>{groups.map(g => <optgroup label={g} key={g}>{services.filter(s => s.group === g).map(s => <option value={s.id} key={s.id}>{s.name} — {money(s.price)}</option>)}</optgroup>)}</select></label><div className="summary"><div><small>{service.name}</small><b>{money(service.price)}</b></div><span>{service.duration === 120 ? '2 horas aprox.' : '2 h 30 min aprox.'}</span></div><label>Tipo de diseño<select value={design} onChange={e => setDesign(e.target.value)}><option>Simple</option><option>Francesa</option><option>Full diseño</option><option>Tengo una referencia</option></select></label><label className="checkline"><input type="checkbox" checked={removal} onChange={e => setRemoval(e.target.checked)}/> Agregar retiro de servicio anterior (+$3.000)</label>
        <div className="form-title second"><span>02 / 03</span><h3>Fecha y horario</h3></div><label>Fecha<input type="date" value={date} min={minDate} max={maxDate} onChange={e => setDate(e.target.value)} required/></label>{date && <div className="slots-wrap"><span className="field-label">HORARIOS DISPONIBLES</span>{loadingSlots ? <p className="muted">Consultando disponibilidad...</p> : slots.length ? <div className="slots">{slots.map(slot => <button type="button" key={slot} className={time === slot ? 'slot active' : 'slot'} onClick={() => setTime(slot)}>{slot}</button>)}</div> : <p className="muted">No hay horarios disponibles para esta fecha y duración. Prueba otro día.</p>}</div>}
        <div className="form-title second"><span>03 / 03</span><h3>Tus datos</h3></div><div className="two-col"><label>Nombre y apellido<input value={name} onChange={e => setName(e.target.value)} placeholder="Tu nombre" required maxLength={90}/></label><label>WhatsApp<input value={phone} onChange={e => setPhone(e.target.value)} placeholder="+56 9 1234 5678" required maxLength={30}/></label></div><label>Correo electrónico <small>(opcional)</small><input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="tucorreo@email.com"/></label><label>Foto de referencia <small>(opcional · máximo 4 MB)</small><input className="file-input" type="file" accept="image/*" onChange={e => chooseImage(e.target.files?.[0])}/>{imageName && <span className="file-name">✓ {imageName}</span>}{image && <img className="preview" src={image} alt="Vista previa de referencia"/>}</label><label>Cuéntanos qué te gustaría realizarte <small>(opcional)</small><textarea value={notes} onChange={e => setNotes(e.target.value)} placeholder="Ej.: largo, colores, detalles del diseño..." rows={3} maxLength={500}/></label>
        <div className="total"><span>Total estimado</span><b>{money(total)}</b></div><p className="deposit-note"><b>Abono para reservar: {depositAmount ? money(depositAmount) : 'Por confirmar'}</b><br/>{paymentInstructions || 'Abono de $5.000 por transferencia. Te enviaremos los datos bancarios por WhatsApp después de revisar tu solicitud.'}<br/>La hora queda confirmada una vez validado el abono.</p><button className="submit" type="submit" disabled={sending}>{sending ? 'ENVIANDO...' : 'SOLICITAR RESERVA'} <span>→</span></button>{status && <div className={status.startsWith('¡Solicitud') ? 'notice success' : 'notice'} role="status">{status}</div>}<p className="privacy">Al enviar, autorizas el uso de tus datos únicamente para gestionar esta reserva.</p>
      </form></section>
    <footer><a className="brand footer-brand" href="#inicio"><span className="monogram">VCG</span><span>NAILS<small>SOFT GEL · KAPPING · ESMALTADO</small></span></a><div><b>VCG Nails</b><p>El Bosque, Santiago · Chile</p><p>Agenda tu hora por Instagram o WhatsApp.</p><p><a href="https://wa.me/56979687302" target="_blank" rel="noreferrer">WhatsApp: +56 9 7968 7302 ↗</a></p></div><a href="https://www.instagram.com/vcg._nailss/" target="_blank" rel="noreferrer">@vcg._nailss ↗</a><small>© {new Date().getFullYear()} VCG Nails</small></footer>
  </main>;
}
