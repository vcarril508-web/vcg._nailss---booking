import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'VCG Nails | Agenda tu hora',
  description: 'Agenda tu servicio de uñas en El Bosque, Santiago. Esmaltado permanente, Kapping y Soft Gel.',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="es"><body>{children}</body></html>;
}
