import { NextRequest, NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  const date = request.nextUrl.searchParams.get('date');
  const duration = request.nextUrl.searchParams.get('duration') || '120';
  const base = process.env.GOOGLE_SCRIPT_URL;
  const secret = process.env.BOOKING_API_SECRET;
  if (!base || !secret) return NextResponse.json({ error: 'El sistema de reservas aún no está configurado.' }, { status: 503 });
  if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date) || !['120', '150'].includes(duration)) return NextResponse.json({ error: 'Fecha o duración inválida.' }, { status: 400 });
  try {
    const url = new URL(base);
    url.searchParams.set('action', 'availability');
    url.searchParams.set('date', date);
    url.searchParams.set('duration', duration);
    url.searchParams.set('token', secret);
    const response = await fetch(url.toString(), { cache: 'no-store', redirect: 'follow' });
    const data = await response.json();
    return NextResponse.json(data, { status: response.ok ? 200 : 502 });
  } catch {
    return NextResponse.json({ error: 'No se pudo consultar la disponibilidad.' }, { status: 502 });
  }
}
