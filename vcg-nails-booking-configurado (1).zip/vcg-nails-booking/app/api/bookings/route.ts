import { NextRequest, NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export async function POST(request: NextRequest) {
  const base = process.env.GOOGLE_SCRIPT_URL;
  const secret = process.env.BOOKING_API_SECRET;
  if (!base || !secret) return NextResponse.json({ error: 'El sistema de reservas aún no está configurado.' }, { status: 503 });
  try {
    const incoming = await request.json();
    const { name, phone, email, service, design, date, time, duration, notes, referenceImage } = incoming;
    if (!name || !phone || !service || !date || !time || !['120', '150'].includes(String(duration))) return NextResponse.json({ error: 'Completa los datos obligatorios.' }, { status: 400 });
    if (typeof name !== 'string' || name.length > 90 || typeof phone !== 'string' || phone.length > 30 || typeof notes === 'string' && notes.length > 500) return NextResponse.json({ error: 'Revisa los datos ingresados.' }, { status: 400 });
    if (referenceImage && (typeof referenceImage !== 'string' || referenceImage.length > 5_500_000)) return NextResponse.json({ error: 'La imagen supera el tamaño permitido (4 MB).' }, { status: 413 });
    const payload = { ...incoming, token: secret };
    const first = await fetch(base, { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify(payload), redirect: 'manual', cache: 'no-store' });
    // Apps Script devuelve normalmente un 302 tras ejecutar doPost; se consulta la URL de salida con GET.
    const redirectUrl = first.headers.get('location');
    const response = redirectUrl && first.status >= 300 && first.status < 400
      ? await fetch(redirectUrl, { method: 'GET', cache: 'no-store' })
      : first;
    const data = await response.json();
    return NextResponse.json(data, { status: response.ok && data.ok ? 200 : 400 });
  } catch {
    return NextResponse.json({ error: 'No se pudo enviar la solicitud. Inténtalo nuevamente.' }, { status: 502 });
  }
}
