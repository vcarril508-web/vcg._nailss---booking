import { NextResponse } from 'next/server';
export const dynamic = 'force-dynamic';
export async function GET() {
  const base = process.env.GOOGLE_SCRIPT_URL;
  const secret = process.env.BOOKING_API_SECRET;
  if (!base || !secret) return NextResponse.json({ depositAmount: 0, paymentInstructions: '' });
  try {
    const url = new URL(base);
    url.searchParams.set('action', 'settings');
    url.searchParams.set('token', secret);
    const response = await fetch(url.toString(), { cache: 'no-store', redirect: 'follow' });
    const data = await response.json();
    return NextResponse.json({ depositAmount: Number(data.depositAmount || 0), paymentInstructions: String(data.paymentInstructions || '') });
  } catch { return NextResponse.json({ depositAmount: 0, paymentInstructions: '' }); }
}
