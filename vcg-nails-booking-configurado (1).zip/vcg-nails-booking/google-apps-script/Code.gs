/** VCG Nails - backend de reservas con Google Sheets + Drive + Gmail */
const SHEET_NAME = 'Reservas';
const DEFAULT_NOTIFICATION_EMAIL = 'vcarril508@gmail.com';
const DEFAULT_DEPOSIT_AMOUNT = 5000;
const HEADERS = ['ID','Creada','Nombre','WhatsApp','Correo','Servicio','Diseño','Fecha','Hora','Duración (min)','Total estimado','Retiro','Notas','Foto referencia (Drive)','Estado'];
function doGet(e) {
  const p = e.parameter || {};
  if (!authorized_(p.token)) return json_({ ok:false, error:'No autorizado.' });
  if (p.action === 'availability') return json_(availability_(p.date, Number(p.duration || 120)));
  if (p.action === 'settings') return json_({ depositAmount:Number(PropertiesService.getScriptProperties().getProperty('DEPOSIT_AMOUNT') || DEFAULT_DEPOSIT_AMOUNT), paymentInstructions:PropertiesService.getScriptProperties().getProperty('PAYMENT_INSTRUCTIONS') || '' });
  return json_({ ok:true, message:'VCG Nails API activa.' });
}
function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents || '{}');
    if (!authorized_(data.token)) return json_({ ok:false, error:'No autorizado.' });
    const required = ['name','phone','service','date','time','duration'];
    if (required.some(k => !data[k])) return json_({ ok:false, error:'Faltan datos obligatorios.' });
    const duration = Number(data.duration);
    if (![120,150].includes(duration)) return json_({ ok:false, error:'Duración inválida.' });
    if (!validDate_(data.date) || data.date < today_() || !validTime_(data.time) || !isWeekday_(data.date)) return json_({ ok:false, error:'Fecha u horario inválido.' });
    const lock = LockService.getScriptLock(); lock.waitLock(20000);
    try {
      const slots = availability_(data.date, duration).slots;
      if (!slots.includes(data.time)) return json_({ ok:false, error:'Ese horario ya no está disponible. Actualiza la página y elige otro.' });
      let photoUrl = '';
      if (data.referenceImage) photoUrl = saveImage_(data.referenceImage, data.name);
      const id = 'VCG-' + Utilities.getUuid().slice(0,8).toUpperCase();
      const sh = sheet_();
      sh.appendRow([id, new Date(), clean_(data.name), clean_(data.phone), clean_(data.email || ''), clean_(data.service), clean_(data.design || ''), data.date, data.time, duration, Number(data.total || 0), data.removal ? 'Sí' : 'No', clean_(data.notes || ''), photoUrl, 'Pendiente de abono']);
      try { notify_(id, data, photoUrl); } catch (mailError) { console.error('No se pudo enviar el aviso: ' + mailError); }
      return json_({ ok:true, bookingId:id });
    } finally { lock.releaseLock(); }
  } catch (err) { return json_({ ok:false, error:String(err.message || err) }); }
}
function availability_(date, duration) {
  if (!validDate_(date) || date < today_() || ![120,150].includes(duration) || !isWeekday_(date)) return { slots:[] };
  const sh = sheet_(); const rows = sh.getLastRow() > 1 ? sh.getRange(2,1,sh.getLastRow()-1,HEADERS.length).getValues() : [];
  const busy = rows.filter(r => String(r[7]) === date && !['Cancelada','Rechazada'].includes(String(r[14]))).map(r => ({ start:toMinutes_(r[8]), end:toMinutes_(r[8]) + Number(r[9] || 120) }));
  const slots = [];
  for (let start = 13*60; start + duration <= 18*60; start += 30) {
    const end = start + duration;
    if (!busy.some(b => start < b.end && end > b.start)) slots.push(('0'+Math.floor(start/60)).slice(-2)+':'+('0'+(start%60)).slice(-2));
  }
  return { slots };
}
function sheet_() {
  const id = PropertiesService.getScriptProperties().getProperty('SPREADSHEET_ID');
  if (!id) throw new Error('Falta configurar SPREADSHEET_ID en las propiedades del script.');
  const ss = SpreadsheetApp.openById(id); let sh = ss.getSheetByName(SHEET_NAME);
  if (!sh) sh = ss.insertSheet(SHEET_NAME);
  if (sh.getLastRow() === 0) { sh.appendRow(HEADERS); sh.setFrozenRows(1); sh.getRange(1,1,1,HEADERS.length).setFontWeight('bold'); }
  return sh;
}
function authorized_(token) { const secret = PropertiesService.getScriptProperties().getProperty('API_SECRET'); return !!secret && token === secret; }
function json_(obj) { return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON); }
function clean_(v) { return String(v == null ? '' : v).replace(/[<>]/g,'').slice(0,1000); }
function validDate_(s) { return /^\d{4}-\d{2}-\d{2}$/.test(String(s)) && !isNaN(new Date(s+'T12:00:00').getTime()); }
function today_() { return Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd'); }
function validTime_(s) { return /^(1[3-7]):(00|30)$/.test(String(s)) || s === '18:00'; }
function isWeekday_(s) { const d = new Date(s+'T12:00:00').getDay(); return d >= 1 && d <= 5; }
function toMinutes_(v) { if (v instanceof Date) return v.getHours()*60+v.getMinutes(); const m=String(v).match(/(\d{1,2}):(\d{2})/); return m ? Number(m[1])*60+Number(m[2]) : 0; }
function saveImage_(dataUrl, name) {
  const match = String(dataUrl).match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,([\s\S]+)$/);
  if (!match) throw new Error('La foto adjunta no es válida.');
  const folderId = PropertiesService.getScriptProperties().getProperty('DRIVE_FOLDER_ID');
  if (!folderId) throw new Error('Falta configurar DRIVE_FOLDER_ID para guardar fotos.');
  const bytes = Utilities.base64Decode(match[2]);
  if (bytes.length > 4*1024*1024) throw new Error('La imagen supera 4 MB.');
  const ext = match[1].split('/')[1].replace('jpeg','jpg');
  const blob = Utilities.newBlob(bytes, match[1], 'Referencia_'+clean_(name).replace(/\s+/g,'_')+'_'+Date.now()+'.'+ext);
  const file = DriveApp.getFolderById(folderId).createFile(blob);
  file.setSharing(DriveApp.Access.PRIVATE, DriveApp.Permission.NONE);
  return file.getUrl();
}
function notify_(id, d, photoUrl) {
  const email = PropertiesService.getScriptProperties().getProperty('NOTIFICATION_EMAIL') || DEFAULT_NOTIFICATION_EMAIL;
  if (!email) return;
  const subject = 'Nueva solicitud de hora - VCG Nails ('+id+')';
  const body = 'Llegó una nueva solicitud de reserva.\n\nCódigo: '+id+'\nNombre: '+d.name+'\nWhatsApp: '+d.phone+'\nCorreo: '+(d.email||'No informado')+'\nServicio: '+d.service+'\nDiseño: '+(d.design||'No informado')+'\nFecha: '+d.date+'\nHora: '+d.time+'\nDuración: '+d.duration+' minutos\nTotal estimado: $'+Number(d.total||0).toLocaleString('es-CL')+'\nRetiro: '+(d.removal?'Sí':'No')+'\nNotas: '+(d.notes||'Sin comentarios')+'\nFoto: '+(photoUrl||'No adjuntó')+'\n\nEstado inicial: Pendiente de abono. Revisa la hoja de cálculo para gestionar la reserva.';
  MailApp.sendEmail(email, subject, body);
}
function setupVCGNails() {
  sheet_();
  const folderId = PropertiesService.getScriptProperties().getProperty('DRIVE_FOLDER_ID');
  if (!folderId) throw new Error('Configura DRIVE_FOLDER_ID antes de ejecutar esta función.');
  DriveApp.getFolderById(folderId).getName();
  MailApp.getRemainingDailyQuota();
  Logger.log('VCG Nails listo. Sheets, Drive y correo autorizados.');
}
